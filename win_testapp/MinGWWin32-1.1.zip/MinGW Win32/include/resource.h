#define IDI_APPICON                     101
#define IDR_MAINMENU                    102
#define IDD_ABOUTDIALOG                 103
#define IDR_ACCELERATOR                 104
#define ID_HELP_ABOUT                   40001
#define ID_FILE_EXIT                    40002

#define IDC_STATIC -1
